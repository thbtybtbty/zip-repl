# GemSpin Bet — clean WispByte runtime package

This ZIP is a fresh runtime package for WispByte and Node.js 19.9.0.

## Included files

- `index.js` — launcher; starts the compiled bot directly and does not create a patched duplicate bundle
- `package.json` and `package-lock.json` — runtime dependency metadata
- `start.sh` — optional start command
- `artifacts/api-server/dist/` — compiled bot runtime files, without source maps
- `artifacts/api-server/admins.json` — admin configuration
- `coinflip_face_assets/` — coinflip image assets

The package intentionally excludes `node_modules`, `.env`, tokens, database files, source maps, Replit files, build tools, and temporary/generated runtime files. WispByte creates `node_modules` when it installs dependencies, and the launcher creates the database only after startup.

## WispByte setup

1. Delete the previous extracted bot files, while backing up `bot.db` first if it contains balances or history.
2. Upload and extract this ZIP into `/home/container`.
3. Set the WispByte main file to `index.js` and use Node.js `19.9.0`.
4. Add `DISCORD_BOT_TOKEN` and `DISCORD_CLIENT_ID` as environment variables.
5. Run `npm install --omit=dev --no-audit --no-fund` once, then start with `node index.js` or `npm start`.

Set `DATABASE_PATH` to a WispByte persistent-data path if WispByte provides one. If it is not set, the launcher uses `/data/bot.db` only when `/data` exists; otherwise it uses `artifacts/api-server/bot.db`.

## Interaction reliability

The bot acknowledges supported interactions before doing database work or animations wherever the command handler requires it. Expired Discord interaction tokens are treated as expected and are not sent through a second reply or logged as an unhandled error. Old buttons pressed after a restart cannot be recovered; press the command again after the bot is ready.

## Storage

If WispByte prints `ENOSPC` or `no space left on device`, the container, npm cache, inode quota, or overlay filesystem is full even if the panel's main storage meter shows free space. The bot cannot write a SQLite database or install dependencies in that state. Clear the npm cache/container files or ask WispByte to reset the container quota. Do not delete `bot.db` unless resetting all balances is intentional.
