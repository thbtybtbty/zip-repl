# Wispbyte Slots Update

This package contains the rebuilt runtime files for the new `/slots` game.

## Install

1. Stop the bot on Wispbyte.
2. Back up the existing `artifacts/api-server/dist/` directory.
3. Extract this archive into the Wispbyte project root and replace the existing `artifacts/api-server/dist/` files.
4. Keep the existing Wispbyte `index.js`, `.env`, `artifacts/api-server/bot.db`, `artifacts/api-server/server-config.json`, and `artifacts/admins.json`.
5. Start the bot using the existing Wispbyte launcher.

## Slots game

- Command: `/slots amount:<bet>`
- Three independent weighted reels using 🍒 🍋 🍉 🍇 💎 ⭐ 7️⃣.
- Triple payouts: 2x, 3x, 4x, 5x, 12x, 8x, and 25x according to the requested table.
- Any exact pair pays 1.2x; everything else loses.
- Theoretical RTP: 84.4583% (approximately 85%).
- Includes staged reel-by-reel animation, result panel, payout table, and Play Again button.
- Integrated with the admin game enable/disable controls and `/simulate`.

This package intentionally does not include secrets, production database files, production configuration, admin data, or `node_modules`.
