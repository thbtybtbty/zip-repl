# Discord Gambling Bot — WispByte package

This is a standalone Node.js package for WispByte. The archive root contains `index.js`, `package.json`, and `start.sh` directly so WispByte can detect the main file.

## WispByte setup

1. Upload this ZIP and extract it into the server root.
2. Select Node.js **19.9.0**. This package is targeted specifically for that runtime.
3. Run `npm install --omit=dev`.
4. Add `DISCORD_BOT_TOKEN` and `DISCORD_CLIENT_ID` as WispByte environment variables.
5. Start with `npm start` or `./start.sh`.

## Important: storage space

If the console shows `ENOSPC`, `no space left on device`, or `Database save failed`, WispByte has run out of storage while saving the SQLite database. This makes commands appear slow and can cause Discord to show `This interaction failed`. Free storage or increase the WispByte disk quota, clear the npm cache if WispByte allows it, then restart the bot. WispByte may report free space in the panel while the container overlay, npm cache, or inode quota is full. Do not delete `bot.db` unless you intentionally want to reset balances and history.

The launcher does not create a patched duplicate of the compiled bundle, which keeps startup storage usage low. It uses `DATABASE_PATH` when provided. Otherwise it uses `/data/bot.db` when `/data` exists, keeping data on the persistent volume; otherwise it uses `artifacts/api-server/bot.db`.

## Interaction errors

`Unknown interaction (10062)` means Discord's three-second acknowledgement window expired. Old buttons clicked while the bot is restarting cannot be recovered; run the command again after the bot is ready. Persistent `10062` errors together with `ENOSPC` are caused by the full WispByte disk, not by the coinflip animation.

## Included runtime

- `index.js` — standalone launcher
- `artifacts/api-server/dist/` — compiled bot, including current coinflip changes
- `coinflip_face_assets/` — coinflip rendering images
- `package.json` and `package-lock.json` — Node 19.9.0 and public npm metadata
- `artifacts/api-server/admins.json` — configured admins

Do not upload `.env`, tokens, or live database files into a public archive.
