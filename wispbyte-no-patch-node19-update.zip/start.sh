#!/usr/bin/env bash
set -euo pipefail
exec node index.js
