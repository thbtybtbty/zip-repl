# Discord Gambling Bot — WispByte package

This archive is a standalone Node.js runtime. It does not need Replit, pnpm, TypeScript, esbuild, or a native SQLite addon. The latest compiled bot, including the current coinflip implementation, is in `artifacts/api-server/dist/`.

## Install on WispByte

1. Upload and extract the archive into the WispByte server root.
2. Use Node.js 20 or newer. Node 19 may work, but Node 20+ is recommended.
3. Run `npm install --omit=dev`.
4. Add these environment variables in WispByte (or put them in `.env`):
   - `DISCORD_BOT_TOKEN` — Discord bot token.
   - `DISCORD_CLIENT_ID` — Discord application/client ID.
5. Start with `npm start` or `./start.sh`.
6. Invite the bot with the `bot` and `applications.commands` scopes and the permissions required by your server.
7. Run `/setup` in Discord as an admin to save the channel and Roblox configuration into the database.

## If WispByte logs `UND_ERR_CONNECT_TIMEOUT`

If installation finishes but the log shows `Connect Timeout Error (attempted address: discord.com:443)`, the package is installed correctly but the WispByte container cannot reach Discord's HTTPS/gateway endpoint. Check that the WispByte host allows outbound TCP 443, that DNS resolves `discord.com`, and that no firewall, proxy, or region block is interfering. Restart the process after the host/network issue is resolved. Reinstalling `@napi-rs/canvas` will not fix this error.

## Database

The launcher uses `DATABASE_PATH` when provided. Otherwise it uses `/data/bot.db` when WispByte exposes `/data`, which keeps the database on the persistent volume. If `/data` is unavailable it falls back to `artifacts/api-server/bot.db`.

The database is created and migrated automatically on first boot. No live database is included in this archive, so uploading it cannot overwrite existing production balances. Back up `/data/bot.db` before replacing a running deployment.

## Admins

`artifacts/api-server/admins.json` contains the admin IDs included by the project. Edit that file on WispByte if the admin list needs to change. The `/addadminperms` command can also manage the file after the bot is online.

## Included runtime

- `index.js` — standalone launcher and `.env` loader
- `artifacts/api-server/dist/` — compiled bot and HTTP server, including current coinflip changes
- `coinflip_face_assets/` — coinflip rendering images
- `package.json` and `package-lock.json` — public npm registry metadata

Do not upload `.env`, tokens, `bot.db`, `bot.db-shm`, or `bot.db-wal` into a source archive or share them publicly.
