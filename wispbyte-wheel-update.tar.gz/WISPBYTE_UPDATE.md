# Wispbyte Wheel Update

This package contains the rebuilt runtime files for the `/wheel` animation variation update.

## Install

1. Stop the bot on Wispbyte.
2. Back up the existing `artifacts/api-server/dist/` directory.
3. Extract this archive into the Wispbyte project root and replace the existing `artifacts/api-server/dist/` files.
4. Keep the existing Wispbyte `index.js`, `.env`, `artifacts/api-server/bot.db`, `artifacts/api-server/server-config.json`, and `artifacts/admins.json`.
5. Start the bot using the existing Wispbyte launcher.

## Change

The wheel uses the same weighted multiplier counts and payout math, but the weighted pool is interleaved instead of grouped. This prevents the animation from showing repeated adjacent `0x` entries while preserving the existing approximately 7.5% house edge.

This package intentionally does not include secrets, production database files, production configuration, or `node_modules`.
