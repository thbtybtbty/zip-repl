=====================================================================
  GAMBLING BOT — WispByte Deployment
=====================================================================

REQUIRED ENVIRONMENT VARIABLES (set these in WispByte's panel):
  DISCORD_BOT_TOKEN   — Bot token from Discord Developer Portal
  DISCORD_CLIENT_ID   — Application ID from Discord Developer Portal
  SESSION_SECRET      — Any long random string (e.g. 64 random characters)

START COMMAND (set this in WispByte):
  bash start.sh

HOW IT WORKS:
  • On first start, start.sh installs better-sqlite3 for WispByte's
    Node version. Subsequent restarts skip this (fast boot).
  • The database is stored as bot.db in the working directory.

DATA PERSISTENCE (important):
  • bot.db is NOT included in this zip — it is created automatically
    on first run and lives in WispByte's persistent storage.
  • When you upload a new bot.zip to update the bot, WispByte will
    overwrite the files from the zip but leave bot.db untouched.
    Your player balances and history are safe across updates.
  • node_modules/ is also not in the zip and persists the same way,
    so the "Installing..." step only runs on the very first boot.

UPDATING THE BOT:
  1. Upload the new bot.zip in WispByte — bot.db is preserved.
  2. Restart the bot in WispByte's panel.

=====================================================================
