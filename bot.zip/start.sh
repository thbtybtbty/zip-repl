#!/bin/bash

# Load .env file (works even if WispByte's panel env vars don't save)
if [ -f ".env" ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

# Install better-sqlite3 on first run only — persists across restarts
if [ ! -d "node_modules/better-sqlite3" ]; then
  echo "[bot] Installing native dependencies for this Node version..."
  npm install --omit=dev
  echo "[bot] Done."
fi

exec node ./index.mjs
