#!/bin/bash

# Install better-sqlite3 on first run (or if node_modules is missing).
# On subsequent restarts this is skipped — node_modules persists on WispByte.
if [ ! -d "node_modules/better-sqlite3" ]; then
  echo "[bot] Installing native dependencies for this Node version..."
  npm install --omit=dev
  echo "[bot] Done."
fi

exec node ./index.mjs
