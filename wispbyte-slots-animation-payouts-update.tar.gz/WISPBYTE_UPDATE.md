# Wispbyte Slots Animation and Payouts Update

This package contains the rebuilt runtime files for the improved `/slots` game.

## Install

1. Stop the bot on Wispbyte.
2. Back up the existing `artifacts/api-server/dist/` directory.
3. Extract this archive into the Wispbyte project root and replace the existing `artifacts/api-server/dist/` files.
4. Keep the existing Wispbyte `index.js`, `.env`, `artifacts/api-server/bot.db`, `artifacts/api-server/server-config.json`, and `artifacts/admins.json`.
5. Start the bot using the existing Wispbyte launcher.

## Changes

- Reduced the animation to six deliberately spaced reel frames to avoid Discord edit bursts.
- Added retry and backoff for transient Discord message-edit failures.
- Animation-frame failures are non-fatal; the paid spin continues to its final result.
- The final result edit has additional retries.
- Removed the payout table from the result embed.
- Added a `📊 Payouts` button beside `🔄 Play Again`.
- The Payouts button opens an ephemeral payout table visible only to the player.

This package intentionally does not include secrets, production database files, production configuration, admin data, or `node_modules`.
