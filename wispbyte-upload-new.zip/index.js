// GemSpin Bet — WispByte entry point
const { execSync, spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

// Persistent database on WispByte's /data volume
if (fs.existsSync("/data")) {
  process.env.DATABASE_PATH = "/data/bot.db";
  console.log("[boot] DB → /data/bot.db (persistent)");
} else {
  process.env.DATABASE_PATH = path.join(__dirname, "bot.db");
  console.log("[boot] DB → " + process.env.DATABASE_PATH);
}

// Install better-sqlite3 if missing (downloads prebuilt binary, no compilation)
if (!fs.existsSync(path.join(__dirname, "node_modules", "better-sqlite3"))) {
  console.log("[boot] Installing better-sqlite3...");
  execSync("npm install better-sqlite3@12.11.1 --no-save --prefer-offline", {
    stdio: "inherit",
    shell: true,
    env: { ...process.env, npm_config_libc: "glibc" },
  });
}

// Start the pre-built bot
console.log("[boot] Starting bot (Node " + process.version + ")...");
const child = spawn(
  process.execPath,
  ["--enable-source-maps", path.join(__dirname, "bot.mjs")],
  { stdio: "inherit", cwd: __dirname, env: process.env }
);
child.on("exit", (code) => process.exit(code ?? 0));
