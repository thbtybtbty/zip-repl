#!/usr/bin/env bash
# PS99 GemSpin Bet — WispByte startup script
set -e

# ─── Persistent data ──────────────────────────────────────────────────────────
if [ -d "/data" ]; then
  export DATABASE_PATH="/data/bot.db"
  echo "[start.sh] Using persistent database at $DATABASE_PATH"
else
  export DATABASE_PATH="/home/container/bot.db"
  echo "[start.sh] Using local database at $DATABASE_PATH"
fi

# ─── Node.js ──────────────────────────────────────────────────────────────────
export NVM_DIR="$HOME/.nvm"
if [ ! -s "$NVM_DIR/nvm.sh" ]; then
  echo "[start.sh] Installing nvm..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
fi
. "$NVM_DIR/nvm.sh"
nvm install 22 --no-progress 2>/dev/null
nvm use 22
echo "[start.sh] Using Node $(node --version)"

# ─── pnpm ─────────────────────────────────────────────────────────────────────
echo "[start.sh] Installing pnpm..."
npm install -g pnpm@9 --prefix "$HOME/.local"
export PATH="$HOME/.local/bin:$PATH"

# ─── Dependencies ─────────────────────────────────────────────────────────────
echo "[start.sh] Installing dependencies..."
# npm_config_libc forces prebuild-install to find the glibc prebuilt binary
# instead of falling back to compiling from source (which needs too much RAM)
npm_config_libc=glibc CI=true pnpm install --no-frozen-lockfile

echo "[start.sh] Building..."
pnpm --filter @workspace/api-server run build

# ─── Start ────────────────────────────────────────────────────────────────────
echo "[start.sh] Starting bot..."
cd artifacts/api-server
exec node --enable-source-maps ./dist/index.mjs
