#!/usr/bin/env bash
# PS99 GemSpin Bet — WispByte startup script
set -e

# ─── Persistent data ──────────────────────────────────────────────────────────
# WispByte mounts a persistent volume at /data.
# Store the SQLite DB there so data survives restarts and code updates.
if [ -d "/data" ]; then
  export DATABASE_PATH="/data/bot.db"
  echo "[start.sh] Using persistent database at $DATABASE_PATH"
else
  export DATABASE_PATH="$(pwd)/bot.db"
  echo "[start.sh] /data not found — using local database at $DATABASE_PATH"
fi

# ─── Node.js ──────────────────────────────────────────────────────────────────
export NVM_DIR="$HOME/.nvm"
if [ ! -s "$NVM_DIR/nvm.sh" ]; then
  echo "[start.sh] Installing nvm..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
fi
. "$NVM_DIR/nvm.sh"
nvm install 20 --no-progress 2>/dev/null
nvm use 20
echo "[start.sh] Using Node $(node --version)"

# ─── pnpm ─────────────────────────────────────────────────────────────────────
echo "[start.sh] Installing pnpm..."
npm install -g pnpm@9 --prefix "$HOME/.local"
export PATH="$HOME/.local/bin:$PATH"

# ─── Dependencies & build ─────────────────────────────────────────────────────
echo "[start.sh] Installing dependencies..."
CI=true pnpm install --no-frozen-lockfile

echo "[start.sh] Building..."
pnpm --filter @workspace/api-server run build

# ─── Start ────────────────────────────────────────────────────────────────────
echo "[start.sh] Starting bot..."
cd artifacts/api-server
exec node --enable-source-maps ./dist/index.mjs
