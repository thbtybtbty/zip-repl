import {
  SlashCommandBuilder,
  EmbedBuilder,
  type ChatInputCommandInteraction,
} from "discord.js";
import { COLORS, getOrCreateUser, formatAmount } from "../utils.js";

export const data = new SlashCommandBuilder()
  .setName("balance")
  .setDescription("View your PS99 Gem balance");

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply();

  const user = await getOrCreateUser(
    interaction.user.id,
    interaction.user.username,
  );

  const balance   = user.balance;
  const deposited = user.deposited ?? 0;
  const withdrawn = user.withdrawn ?? 0;
  const wagered   = user.wagered   ?? 0;
  // profit = current balance + lifetime withdrawals - lifetime deposits
  const profit    = balance + withdrawn - deposited;

  const profitPositive = profit >= 0;
  const profitEmoji    = profitPositive ? "📈" : "📉";
  const profitStr      = `${profitPositive ? "+" : "-"}${formatAmount(Math.abs(profit))}`;

  const embed = new EmbedBuilder()
    .setColor(profitPositive ? 0x57f287 : 0xed4245)
    .setTitle(`💎 ${interaction.user.displayName}'s Balance`)
    .setThumbnail(interaction.user.displayAvatarURL({ size: 128 }))
    .setDescription(
      [
        `💎 **Balance**   \`${formatAmount(balance)}\` *(${balance.toLocaleString("en-US")})*`,
        `📥 **Deposited** \`${formatAmount(deposited)}\``,
        `📤 **Withdrawn** \`${formatAmount(withdrawn)}\``,
        `💸 **Wagered**   \`${formatAmount(wagered)}\``,
        `${profitEmoji} **Profit**    \`${profitStr}\``,
      ].join("\n"),
    )
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}
